n = int(input("입력값: "))
j = 1
for i in range(5, 0, -1):
    j *=i

print(j)