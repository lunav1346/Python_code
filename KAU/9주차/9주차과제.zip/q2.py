from re import I


a = int(input("입력: "))
s = 0
for i in range(1, a, 2):
    s = s + i
    print(s)