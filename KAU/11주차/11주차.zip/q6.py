def reverseStr(x) ->str:
    return x[::-1]

print(reverseStr("ABCD"))
