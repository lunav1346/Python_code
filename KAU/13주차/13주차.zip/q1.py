def func3():
    global r, g, b
    r = 3
    g = 4
    b = 5

    print(r, g, b)

func3()

print(r, g, b)